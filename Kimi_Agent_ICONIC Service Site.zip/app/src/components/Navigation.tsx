import { useEffect, useState } from 'react';

export function Navigation() {
  const [isVisible, setIsVisible] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setIsScrolled(scrollY > 50);
      setIsVisible(scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
      } ${isScrolled ? 'bg-[#0B3C4A]/90 backdrop-blur-sm' : ''}`}
    >
      <div className="flex items-center justify-between px-[7vw] py-6">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <span className="label-mono text-white tracking-[0.2em]">ICONIC</span>
          <span className="label-mono text-white/50 text-[0.65rem]">CONSTRUCTION</span>
        </div>

        {/* Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {[
            { label: 'Work', id: 'section-2' },
            { label: 'Services', id: 'section-3' },
            { label: 'Studio', id: 'section-7' },
            { label: 'Contact', id: 'section-9' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className="label-mono text-white/70 hover:text-gold transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
