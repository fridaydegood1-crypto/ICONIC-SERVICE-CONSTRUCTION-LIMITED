import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Navigation } from './components/Navigation';
import { HeroSection } from './sections/HeroSection';
import { FullBleedSection } from './sections/FullBleedSection';
import { ProcessSection } from './sections/ProcessSection';
import { ContactSection } from './sections/ContactSection';

gsap.registerPlugin(ScrollTrigger);

function App() {
  // Global scroll snap for pinned sections
  useEffect(() => {
    // Wait for all ScrollTriggers to be created
    const timeout = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter((st) => st.vars.pin)
        .sort((a, b) => a.start - b.start);

      const maxScroll = ScrollTrigger.maxScroll(window);

      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map((st) => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            // Check if within any pinned range (allow small buffer)
            const inPinned = pinnedRanges.some(
              (r) => value >= r.start - 0.02 && value <= r.end + 0.02
            );

            if (!inPinned) return value; // Flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );

            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 100);

    return () => {
      clearTimeout(timeout);
    };
  }, []);

  // Cleanup all ScrollTriggers on unmount
  useEffect(() => {
    return () => {
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  return (
    <div className="grain-overlay">
      <Navigation />

      <main className="relative">
        {/* Section 1: Hero - Split screen */}
        <HeroSection />

        {/* Section 2: Design That Delivers - Full bleed, right aligned */}
        <FullBleedSection
          id="section-2"
          image="/statement_building.jpg"
          headline={['DESIGN THAT', 'DELIVERS']}
          body="We translate complex briefs into calm, confident builds—managing compliance, coordination, and finish."
          cta="See how we work"
          alignment="right"
          showHairline={true}
          zIndex={20}
        />

        {/* Section 3: From Concept to Completion - Two images */}
        <ProcessSection />

        {/* Section 4: Details Matter - Full bleed, left aligned */}
        <FullBleedSection
          id="section-4"
          image="/interior_detail.jpg"
          headline={['DETAILS', 'MATTER']}
          body="Joints, junctions, finishes—we obsess over the small things so the big picture feels inevitable."
          cta="Explore finishes"
          alignment="left"
          zIndex={40}
        />

        {/* Section 5: Built for Living - Full bleed, right aligned */}
        <FullBleedSection
          id="section-5"
          image="/living_room.jpg"
          headline={['BUILT FOR', 'LIVING']}
          body="Spaces that feel as good as they look—natural light, honest materials, and layouts that fit real life."
          cta="View homes"
          alignment="right"
          showHairline={true}
          zIndex={50}
        />

        {/* Section 6: Quality You Can See - Full bleed, left aligned */}
        <FullBleedSection
          id="section-6"
          image="/kitchen.jpg"
          headline={['QUALITY YOU', 'CAN SEE']}
          body="We specify durable, beautiful materials and install them with care—so every surface ages gracefully."
          cta="See materials"
          alignment="left"
          zIndex={60}
        />

        {/* Section 7: Collaboration at Every Step - Full bleed, right aligned */}
        <FullBleedSection
          id="section-7"
          image="/workspace.jpg"
          headline={['COLLABORATION', 'AT EVERY STEP']}
          body="Weekly updates, clear decisions, and a team that listens—so you're never left guessing."
          cta="Start a project"
          alignment="right"
          showHairline={true}
          zIndex={70}
        />

        {/* Section 8: Live Iconically - Full bleed, left aligned */}
        <FullBleedSection
          id="section-8"
          image="/modern_living.jpg"
          headline={['LIVE', 'ICONICALLY']}
          body="Homes and spaces designed to feel timeless—clean lines, warm textures, and a sense of calm."
          cta="Book a consultation"
          alignment="left"
          zIndex={80}
        />

        {/* Section 9: Contact - Flowing section */}
        <ContactSection />
      </main>
    </div>
  );
}

export default App;
