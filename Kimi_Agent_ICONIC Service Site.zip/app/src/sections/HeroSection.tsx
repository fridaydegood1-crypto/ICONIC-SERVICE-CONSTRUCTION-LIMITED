import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const photo = photoRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;
    const nav = navRef.current;

    if (!section || !photo || !headline || !subhead || !cta || !nav) return;

    const ctx = gsap.context(() => {
      // Set initial states for entrance animation
      gsap.set(photo, { x: '-60vw', opacity: 0, scale: 0.98 });
      gsap.set(headline.querySelectorAll('.headline-line'), { x: '18vw', opacity: 0 });
      gsap.set([subhead, cta], { y: 24, opacity: 0 });
      gsap.set(nav, { y: -20, opacity: 0 });

      // Auto-play entrance animation on load
      const entranceTl = gsap.timeline({ delay: 0.2 });

      entranceTl
        .to(nav, { y: 0, opacity: 1, duration: 0.6, ease: 'power3.out' })
        .to(photo, { x: 0, opacity: 1, scale: 1, duration: 1, ease: 'power3.out' }, '-=0.4')
        .to(headline.querySelectorAll('.headline-line'), {
          x: 0,
          opacity: 1,
          duration: 0.7,
          stagger: 0.08,
          ease: 'power3.out',
        }, '-=0.6')
        .to(subhead, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' }, '-=0.3')
        .to(cta, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' }, '-=0.3');

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.to(photo, { x: 0, y: 0, scale: 1, opacity: 1, duration: 0.3 });
            gsap.to(headline.querySelectorAll('.headline-line'), { x: 0, opacity: 1, duration: 0.3 });
            gsap.to([subhead, cta], { y: 0, opacity: 1, duration: 0.3 });
          },
        },
      });

      // SETTLE phase (0% - 70%): Hold position
      // EXIT phase (70% - 100%): Elements exit
      scrollTl
        .fromTo(
          photo,
          { x: 0, y: 0, scale: 1, opacity: 1 },
          { x: '-18vw', y: '10vh', scale: 0.92, opacity: 0.25, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          headline.querySelectorAll('.headline-line'),
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0.25, stagger: 0.02, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          [subhead, cta],
          { y: 0, opacity: 1 },
          { y: '8vh', opacity: 0.2, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToWork = () => {
    const element = document.getElementById('section-2');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="section-1"
      className="section-pinned bg-[#0B3C4A] z-10"
    >
      {/* Navigation (visible on hero) */}
      <div ref={navRef} className="absolute top-0 left-0 w-full z-20">
        <div className="flex items-center justify-between px-[7vw] py-6">
          <div className="flex items-center gap-3">
            <span className="label-mono text-white tracking-[0.2em]">ICONIC</span>
            <span className="label-mono text-white/50 text-[0.65rem]">CONSTRUCTION</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            {['Work', 'Services', 'Studio', 'Contact'].map((item) => (
              <button
                key={item}
                onClick={() => {
                  const id = item === 'Work' ? 'section-2' : item === 'Services' ? 'section-3' : item === 'Studio' ? 'section-7' : 'section-9';
                  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="label-mono text-white/70 hover:text-gold transition-colors"
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Photo Card */}
      <div
        ref={photoRef}
        className="absolute left-[7vw] top-[18vh] w-[40vw] h-[64vh] image-card overflow-hidden"
      >
        <img
          src="/hero_architecture.jpg"
          alt="Modern Architecture"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Typography Block */}
      <div className="absolute left-[56vw] top-[30vh] w-[37vw]">
        {/* Headline */}
        <div ref={headlineRef} className="space-y-1">
          <div className="headline-line headline-xl text-white text-[clamp(2.5rem,5vw,4.5rem)]">
            MODERN
          </div>
          <div className="headline-line headline-xl text-gold text-[clamp(2.5rem,5vw,4.5rem)]">
            SPACES
          </div>
          <div className="headline-line headline-xl text-white text-[clamp(1.5rem,2.5vw,2.5rem)]">
            BUILT WITH PRECISION
          </div>
        </div>

        {/* Subheadline */}
        <p
          ref={subheadRef}
          className="mt-8 text-white/70 text-base leading-relaxed max-w-[30vw]"
        >
          Design-led construction for homes and commercial spaces—on time, on budget, quietly excellent.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="mt-8 flex items-center gap-4">
          <button className="btn-primary rounded-sm">
            Start a project
          </button>
          <button onClick={scrollToWork} className="btn-secondary rounded-sm flex items-center gap-2">
            View our work
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
