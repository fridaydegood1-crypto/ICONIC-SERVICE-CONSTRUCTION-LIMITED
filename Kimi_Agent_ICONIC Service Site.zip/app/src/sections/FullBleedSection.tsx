import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FullBleedSectionProps {
  id: string;
  image: string;
  headline: [string, string];
  body: string;
  cta: string;
  alignment: 'left' | 'right';
  showHairline?: boolean;
  zIndex: number;
}

export function FullBleedSection({
  id,
  image,
  headline,
  body,
  cta,
  alignment,
  showHairline = false,
  zIndex,
}: FullBleedSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const hairlineRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const bg = bgRef.current;
    const hairline = hairlineRef.current;
    const headlineEl = headlineRef.current;
    const bodyEl = bodyRef.current;
    const ctaEl = ctaRef.current;

    if (!section || !bg || !headlineEl || !bodyEl || !ctaEl) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      const bgFromX = alignment === 'right' ? '-6vw' : '6vw';
      const bgToX = alignment === 'right' ? '3vw' : '-3vw';
      const headlineFromX = alignment === 'right' ? '22vw' : '-22vw';
      const headlineToX = alignment === 'right' ? '10vw' : '-10vw';

      scrollTl
        // Background entrance
        .fromTo(
          bg,
          { scale: 1.12, x: bgFromX, opacity: 0.6 },
          { scale: 1, x: 0, opacity: 1, ease: 'none' },
          0
        )
        // Hairline entrance
        .fromTo(
          hairline,
          { scaleX: 0, transformOrigin: 'left center' },
          { scaleX: 1, ease: 'none' },
          0
        )
        // Headline entrance
        .fromTo(
          headlineEl.querySelectorAll('.headline-line'),
          { x: headlineFromX, opacity: 0 },
          { x: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0
        )
        // Body + CTA entrance
        .fromTo(
          [bodyEl, ctaEl],
          { y: 28, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
          0.05
        );

      // SETTLE (30% - 70%) - Hold position

      // EXIT (70% - 100%)
      scrollTl
        .fromTo(
          headlineEl.querySelectorAll('.headline-line'),
          { x: 0, opacity: 1 },
          { x: headlineToX, opacity: 0.25, stagger: 0.01, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          [bodyEl, ctaEl],
          { y: 0, opacity: 1 },
          { y: '6vh', opacity: 0.2, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          bg,
          { scale: 1, x: 0, opacity: 1 },
          { scale: 1.06, x: bgToX, opacity: 0.35, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          hairline,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.85
        );
    }, section);

    return () => ctx.revert();
  }, [alignment]);

  const isRight = alignment === 'right';

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned"
      style={{ zIndex, backgroundColor: '#0B3C4A' }}
    >
      {/* Full-bleed background image */}
      <div
        ref={bgRef}
        className="absolute inset-0 w-full h-full"
      >
        <img
          src={image}
          alt={headline.join(' ')}
          className="w-full h-full object-cover"
        />
        {/* Dark overlay for text readability */}
        <div className={`absolute inset-0 ${isRight ? 'bg-gradient-to-l' : 'bg-gradient-to-r'} from-[#0B3C4A]/80 via-[#0B3C4A]/40 to-transparent`} />
      </div>

      {/* Hairline */}
      {showHairline && (
        <div
          ref={hairlineRef}
          className="absolute left-[7vw] top-[14vh] w-[86vw] hairline"
        />
      )}

      {/* Content block */}
      <div
        className={`absolute ${isRight ? 'left-[58vw]' : 'left-[7vw]'} top-[26vh] w-[35vw]`}
      >
        {/* Headline */}
        <div ref={headlineRef} className="space-y-1">
          <div className="headline-line headline-xl text-white text-[clamp(2rem,4vw,3.5rem)]">
            {headline[0]}
          </div>
          <div className="headline-line headline-xl text-gold text-[clamp(2rem,4vw,3.5rem)]">
            {headline[1]}
          </div>
        </div>
      </div>

      {/* Body */}
      <div
        ref={bodyRef}
        className={`absolute ${isRight ? 'left-[58vw]' : 'left-[7vw]'} top-[56vh] w-[30vw]`}
      >
        <p className="text-white/70 text-base leading-relaxed">
          {body}
        </p>
      </div>

      {/* CTA */}
      <button
        ref={ctaRef}
        className={`absolute ${isRight ? 'left-[58vw]' : 'left-[7vw]'} top-[72vh] btn-secondary rounded-sm flex items-center gap-2`}
      >
        {cta}
        <ArrowRight className="w-4 h-4" />
      </button>
    </section>
  );
}
