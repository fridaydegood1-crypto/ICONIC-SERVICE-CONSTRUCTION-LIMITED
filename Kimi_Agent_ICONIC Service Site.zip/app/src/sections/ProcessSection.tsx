import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function ProcessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageARef = useRef<HTMLDivElement>(null);
  const imageBRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const imageA = imageARef.current;
    const imageB = imageBRef.current;
    const headline = headlineRef.current;
    const body = bodyRef.current;
    const cta = ctaRef.current;

    if (!section || !imageA || !imageB || !headline || !body || !cta) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        // Image A entrance
        .fromTo(
          imageA,
          { x: '-60vw', opacity: 0, scale: 0.96 },
          { x: 0, opacity: 1, scale: 1, ease: 'none' },
          0
        )
        // Image B entrance (slightly delayed)
        .fromTo(
          imageB,
          { x: '-40vw', y: '10vh', opacity: 0, scale: 0.96 },
          { x: 0, y: 0, opacity: 1, scale: 1, ease: 'none' },
          0.08
        )
        // Headline entrance
        .fromTo(
          headline.querySelectorAll('.headline-line'),
          { x: '22vw', opacity: 0 },
          { x: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0
        )
        // Body + CTA entrance
        .fromTo(
          [body, cta],
          { y: 28, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
          0.05
        );

      // SETTLE (30% - 70%) - Hold position

      // EXIT (70% - 100%)
      scrollTl
        .fromTo(
          [imageA, imageB],
          { x: 0, y: 0, opacity: 1 },
          { x: '-10vw', y: '8vh', opacity: 0.25, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          headline.querySelectorAll('.headline-line'),
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0.25, stagger: 0.01, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          [body, cta],
          { y: 0, opacity: 1 },
          { y: '6vh', opacity: 0.2, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="section-3"
      className="section-pinned bg-[#0B3C4A]"
      style={{ zIndex: 30 }}
    >
      {/* Image A (larger) */}
      <div
        ref={imageARef}
        className="absolute left-[7vw] top-[18vh] w-[38vw] h-[64vh] image-card overflow-hidden"
      >
        <img
          src="/process_construction_a.jpg"
          alt="Construction Process"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Image B (smaller, overlapping) */}
      <div
        ref={imageBRef}
        className="absolute left-[34vw] top-[40vh] w-[26vw] h-[44vh] image-card overflow-hidden"
      >
        <img
          src="/process_construction_b.jpg"
          alt="Construction Detail"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Headline */}
      <div
        ref={headlineRef}
        className="absolute left-[62vw] top-[28vh] w-[32vw] space-y-1"
      >
        <div className="headline-line headline-xl text-white text-[clamp(2rem,4vw,3.5rem)]">
          FROM CONCEPT
        </div>
        <div className="headline-line headline-xl text-gold text-[clamp(2rem,4vw,3.5rem)]">
          TO COMPLETION
        </div>
      </div>

      {/* Body */}
      <div
        ref={bodyRef}
        className="absolute left-[62vw] top-[56vh] w-[28vw]"
      >
        <p className="text-white/70 text-base leading-relaxed">
          A single team from sketch to handover—clear timelines, transparent costs, no surprises.
        </p>
      </div>

      {/* CTA */}
      <button
        ref={ctaRef}
        className="absolute left-[62vw] top-[72vh] btn-secondary rounded-sm flex items-center gap-2"
      >
        Meet the team
        <ArrowRight className="w-4 h-4" />
      </button>
    </section>
  );
}
