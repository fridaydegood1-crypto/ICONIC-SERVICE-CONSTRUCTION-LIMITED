import { useRef, useLayoutEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftColRef = useRef<HTMLDivElement>(null);
  const formCardRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    projectType: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const leftCol = leftColRef.current;
    const formCard = formCardRef.current;

    if (!section || !leftCol || !formCard) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        leftCol,
        { x: '-8vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        formCard,
        { x: '8vw', opacity: 0, y: 24 },
        {
          x: 0,
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <section
      ref={sectionRef}
      id="section-9"
      className="relative min-h-screen bg-[#F4F6F6] py-[10vh]"
      style={{ zIndex: 90 }}
    >
      <div className="relative px-[7vw]">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-8">
          {/* Left Column - Contact Info */}
          <div ref={leftColRef} className="lg:w-[34vw]">
            <h2 className="headline-lg text-[#0B3C4A] text-[clamp(2rem,3.5vw,3rem)] mb-6">
              Let's build something <span className="text-gold">precise.</span>
            </h2>
            <p className="text-[#0B3C4A]/70 text-base leading-relaxed mb-10">
              Tell us what you're planning. We'll respond within two business days.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Mail className="w-5 h-5 text-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="label-mono text-[#0B3C4A]/50 text-xs mb-1">NEW BUSINESS</p>
                  <p className="text-[#0B3C4A] font-medium">hello@iconicconstruction.co</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="w-5 h-5 text-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="label-mono text-[#0B3C4A]/50 text-xs mb-1">PHONE</p>
                  <p className="text-[#0B3C4A] font-medium">+1 (212) 555-0138</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MapPin className="w-5 h-5 text-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="label-mono text-[#0B3C4A]/50 text-xs mb-1">OFFICE</p>
                  <p className="text-[#0B3C4A] font-medium">144 Canal Street, Suite 400</p>
                  <p className="text-[#0B3C4A]/70">New York, NY</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="w-5 h-5 text-gold mt-1 flex-shrink-0" />
                <div>
                  <p className="label-mono text-[#0B3C4A]/50 text-xs mb-1">HOURS</p>
                  <p className="text-[#0B3C4A] font-medium">Mon–Fri, 8am–6pm</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Form Card */}
          <div
            ref={formCardRef}
            className="lg:w-[41vw] bg-white border border-[#0B3C4A]/12 p-8 lg:p-10"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mb-6">
                  <Send className="w-8 h-8 text-gold" />
                </div>
                <h3 className="headline-lg text-[#0B3C4A] text-2xl mb-3">Message Sent</h3>
                <p className="text-[#0B3C4A]/70">We'll be in touch within two business days.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="label-mono text-[#0B3C4A]/50 text-xs mb-2 block">NAME</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="form-input"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="label-mono text-[#0B3C4A]/50 text-xs mb-2 block">EMAIL</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="form-input"
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <label className="label-mono text-[#0B3C4A]/50 text-xs mb-2 block">PROJECT TYPE</label>
                  <select
                    name="projectType"
                    value={formData.projectType}
                    onChange={handleChange}
                    required
                    className="form-input"
                  >
                    <option value="">Select project type</option>
                    <option value="residential">Residential</option>
                    <option value="commercial">Commercial</option>
                    <option value="renovation">Renovation</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="label-mono text-[#0B3C4A]/50 text-xs mb-2 block">MESSAGE</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={4}
                    className="form-input resize-none"
                    placeholder="Tell us about your project..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary rounded-sm justify-center"
                >
                  Send message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-0 left-0 w-full bg-[#0B3C4A] py-6">
        <div className="px-[7vw] flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="label-mono text-white tracking-[0.2em]">ICONIC</span>
            <span className="label-mono text-white/50 text-[0.65rem]">CONSTRUCTION</span>
          </div>
          <p className="text-white/50 text-sm">
            © ICONIC SERVICE CONSTRUCTION LIMITED. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}
